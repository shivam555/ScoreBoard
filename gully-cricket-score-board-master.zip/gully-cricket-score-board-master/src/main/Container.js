import React, { Fragment } from 'react'
import Main from './Main'

const Container = () => {
  return (
    <Fragment>
      <Main />
    </Fragment>
  )
}

export default Container
