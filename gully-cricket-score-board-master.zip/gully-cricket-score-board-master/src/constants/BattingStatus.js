export const BATTING = 'Batting'
export const YET_TO_BAT = 'Yet to Bat'
export const OUT = 'Out'
